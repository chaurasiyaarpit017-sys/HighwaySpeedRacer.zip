package com.example.highwayspeedracer

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.random.Random

class RacingView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var carX = 0f
    private var roadOffset = 0f
    private var score = 0
    private var coins = 0
    private var gameOver = false
    private var lastTime = System.currentTimeMillis()
    private val enemies = mutableListOf<Enemy>()
    private val coinList = mutableListOf<Coin>()

    data class Enemy(var lane: Int, var y: Float, var speed: Float, var color: Int)
    data class Coin(var lane: Int, var y: Float)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        val now = System.currentTimeMillis()
        val dt = ((now-lastTime).coerceAtMost(40))/1000f
        lastTime = now

        // Sky and grass
        c.drawColor(Color.rgb(100,180,235))
        p.color = Color.rgb(40,150,55); c.drawRect(0,h*.38f,w,h,p)

        // Perspective road
        val topW=w*.22f; val botW=w*.92f
        val path=Path()
        path.moveTo((w-topW)/2,h*.38f); path.lineTo((w+topW)/2,h*.38f)
        path.lineTo((w+botW)/2,h); path.lineTo((w-botW)/2,h); path.close()
        p.color=Color.DKGRAY; c.drawPath(path,p)

        // Road edge
        p.color=Color.WHITE; p.strokeWidth=8f
        c.drawLine((w-topW)/2,h*.38f,(w-botW)/2,h,p)
        c.drawLine((w+topW)/2,h*.38f,(w+botW)/2,h,p)

        // Lane markings
        roadOffset += 420f*dt
        if(roadOffset>90) roadOffset-=90
        p.strokeWidth=10f
        for(lane in 1..2){
            val t=lane/3f
            var y=h*.40f-roadOffset*.002f
            while(y<h){
                val yy=y
                val progress=(yy-h*.38f)/(h*.62f)
                val half=topW/2+(botW-topW)/2*progress
                val x=w/2-half+(2*half)*t
                val len=20+70*progress
                p.color=Color.YELLOW
                c.drawLine(x,yy,x,yy+len,p)
                y+=90+60*progress
            }
        }

        if(!gameOver){
            if(carX==0f) carX=w/2
            update(dt,w,h)
        }

        drawEnemies(c,w,h)
        drawCoins(c,w,h)
        drawPlayer(c,w,h)
        drawHud(c,w,h)

        if(gameOver){
            p.color=0xCC000000.toInt(); c.drawRect(0,0,w,h,p)
            text(c,"CRASH!",w/2,h*.40f,56f,Color.WHITE,true)
            text(c,"Score: $score   Coins: $coins",w/2,h*.49f,26f,Color.WHITE,true)
            text(c,"TAP TO PLAY AGAIN",w/2,h*.60f,28f,Color.YELLOW,true)
        } else postInvalidateDelayed(16)
    }

    private fun update(dt:Float,w:Float,h:Float){
        score += (dt*10).toInt()
        if(Random.nextFloat()<dt*0.65f) enemies.add(Enemy(Random.nextInt(3),-120f,280f+Random.nextFloat()*180f,
            intArrayOf(Color.RED,Color.BLUE,Color.MAGENTA,Color.CYAN)[Random.nextInt(4)]))
        if(Random.nextFloat()<dt*0.5f) coinList.add(Coin(Random.nextInt(3),-40f))
        enemies.forEach { it.y += it.speed*dt }
        coinList.forEach { it.y += 300f*dt }
        enemies.removeAll { it.y>h+150 }
        coinList.removeAll { it.y>h+50 }
        val playerY=h*.80f
        enemies.removeAll {
            val ex=laneX(it.lane,w,it.y,h)
            if(it.y>playerY-70 && it.y<playerY+80 && abs(ex-carX)<65){ gameOver=true; true } else false
        }
        coinList.removeAll {
            val cx=laneX(it.lane,w,it.y,h)
            if(it.y>playerY-65 && it.y<playerY+65 && abs(cx-carX)<60){ coins++; score+=50; true } else false
        }
    }

    private fun laneX(lane:Int,w:Float,y:Float,h:Float):Float{
        val topW=w*.22f; val botW=w*.92f
        val progress=((y-h*.38f)/(h*.62f)).coerceIn(0f,1f)
        val half=topW/2+(botW-topW)/2*progress
        return w/2-half+(2*half)*(lane/2f)
    }

    private fun drawPlayer(c:Canvas,w:Float,h:Float){
        val y=h*.80f
        drawCar(c,carX,y,Color.rgb(255,210,20),w*.12f)
    }
    private fun drawEnemies(c:Canvas,w:Float,h:Float){
        enemies.forEach { drawCar(c,laneX(it.lane,w,it.y,h),it.y,it.color,w*.10f) }
    }
    private fun drawCar(c:Canvas,x:Float,y:Float,color:Int,size:Float){
        p.color=color
        c.drawRoundRect(x-size,y-size*1.35f,x+size,y+size*1.35f,size*.25f,size*.25f,p)
        p.color=Color.rgb(30,30,30)
        c.drawRect(x-size*.72f,y-size*.72f,x+size*.72f,y-size*.20f,p)
        p.color=Color.WHITE
        c.drawRect(x-size*.58f,y-size*.64f,x+size*.58f,y-size*.34f,p)
        p.color=Color.BLACK
        c.drawCircle(x-size*.72f,y+size*.85f,size*.22f,p)
        c.drawCircle(x+size*.72f,y+size*.85f,size*.22f,p)
        c.drawCircle(x-size*.72f,y-size*.85f,size*.22f,p)
        c.drawCircle(x+size*.72f,y-size*.85f,size*.22f,p)
    }
    private fun drawCoins(c:Canvas,w:Float,h:Float){
        coinList.forEach {
            val x=laneX(it.lane,w,it.y,h)
            p.color=Color.YELLOW; c.drawCircle(x,it.y,18f,p)
            p.color=Color.rgb(180,120,0); p.style=Paint.Style.STROKE; p.strokeWidth=5f
            c.drawCircle(x,it.y,13f,p); p.style=Paint.Style.FILL
        }
    }
    private fun drawHud(c:Canvas,w:Float,h:Float){
        text(c,"SCORE $score",20f,48f,22f,Color.WHITE,false)
        text(c,"COINS $coins",w-20f,48f,22f,Color.WHITE,true)
        text(c,"← SWIPE / TAP →",w/2,h-22f,18f,Color.WHITE,true)
    }
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,center:Boolean){
        p.color=color; p.textSize=size; p.typeface=Typeface.DEFAULT_BOLD
        p.textAlign=if(center) Paint.Align.CENTER else Paint.Align.LEFT
        c.drawText(s,x,y,p)
    }
    override fun onTouchEvent(e:MotionEvent):Boolean{
        if(e.action==MotionEvent.ACTION_DOWN){
            if(gameOver){ gameOver=false; score=0; coins=0; enemies.clear(); coinList.clear(); lastTime=System.currentTimeMillis(); return true }
            carX = e.x
            invalidate()
        } else if(e.action==MotionEvent.ACTION_MOVE){
            if(!gameOver) carX=e.x.coerceIn(width*.15f,width*.85f)
        }
        return true
    }
}
