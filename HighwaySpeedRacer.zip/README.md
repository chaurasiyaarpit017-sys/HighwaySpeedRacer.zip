# Highway Speed Racer

A simple Android car-racing game made as a starter Play Store project.

## Build
Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then:
Build > Generate Signed App Bundle / APK > Android App Bundle.

## Controls
Touch and drag left/right to steer. Avoid traffic and collect coins.

## Play Store
Before publishing, add your own app icon, screenshots, privacy policy if applicable, store listing, and a signed AAB. Check current Google Play target-API and developer-account requirements before upload.
